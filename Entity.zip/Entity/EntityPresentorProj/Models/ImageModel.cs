﻿namespace EntityPresentorProj.Models
{
    public class ImageModel
    {
        public string Name { get; set; }

        public byte[] InternalImage { get; set; }
        public DateTime UpdateDate { get; set; }
    }

}
