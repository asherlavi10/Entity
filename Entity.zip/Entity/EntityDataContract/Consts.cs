﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityDataContract
{
    public  class Consts
    {
        public const string MainImage = "/img/world-map.gif";
    }
}
